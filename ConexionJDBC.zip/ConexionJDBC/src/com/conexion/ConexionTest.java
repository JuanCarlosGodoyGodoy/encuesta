package com.conexion;

import static org.junit.Assert.*;

import org.junit.Test;

public class ConexionTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
